<?php
session_start();
$con = mysqli_connect('localhost','root',"");
mysqli_select_db($con, 'attendence');
// Check connection
$tid=$_GET['status'];
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}

// sql to delete a record
$sql_v= "SELECT * FROM teacher WHERE tid=$tid";
$query=mysqli_query($con,$sql_v);
if(mysqli_num_rows($query))
{
  $sql = "DELETE FROM teacher WHERE tid=$tid";
  mysqli_query($con, $sql);
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . mysqli_error($con);
}

mysqli_close($con);
?>
<center><a href="../HOD/action.php"><button class="btn" type="button" ><b>Go Back</b></button></a></center>
