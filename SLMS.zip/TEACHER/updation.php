<?php
$con = mysqli_connect('localhost','root',"");
mysqli_select_db($con, 'attendence');
session_start();
if(isset($_SESSION['tid']))
       {

           $tid=$_SESSION['tid'];
               if(isset($_POST['submit']))
               {
                 // $id = $row['tid'];
                 $name=$_POST['name'];
                 $branch=$_POST['branch'];
                 $subject=$_POST['subject'];
                 $co_ordinator=$_POST['co_ordinator'];
                 $gender=$_POST['gender'];
                 $dob=$_POST['dob'];
                 $phone=$_POST['phone'];
                 $mail=$_POST['mail'];
                 $address=$_POST['address'];
                 $password=$_POST['password'];

                 $query3 = mysqli_query($con,"UPDATE teacher SET name='$name',branch='$branch',subject='$subject',co_ordinator='$co_ordinator',gender='$gender',dob='$dob',phone='$phone', mail='$mail',address='$address', password='$password' WHERE tid=$tid");

                   if ($query3){
                      echo "<script type='text/javascript'>alert('Successful - Record Updated!'); window.location.href = 'action.php';</script>"; 
                  }
                   else
                       { echo "<script type='text/javascript'>alert('Unsuccessful - ERROR!'); window.location.href = 'user_list.php';</script>"; }
               }

   $query1=mysql_query("SELECT * FROM teacher WHERE tid='$tid'");
   $query2=mysql_fetch_array($query1);



   }
 ?>
