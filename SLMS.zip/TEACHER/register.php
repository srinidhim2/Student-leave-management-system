
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">

    .btn:hover{
      background: rgb(2,0,36);
    background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(158,176,27,1) 35%, rgba(0,212,255,1) 100%);
    border: none;
    color: Black;
    padding: 18px 36px;
    text-align: center;
    font-size: 16px;
    margin: 4px 2px;
    opacity: 0.6;
    transition: 0.3s;
    display: inline-block;
    text-decoration: none;
    cursor: pointer;
    }
    </style>
  </head>
  <body>
    <?php
    session_start();
    $con = mysqli_connect('localhost','root',"");
    mysqli_select_db($con, 'attendence');
    // $usn=$_POST['usn'];
    $name=$_POST['name'];
    $branch=$_POST['branch'];
    $subject=$_POST['subject'];
    $co_ordinator=$_POST['classid'];
    $dob=$_POST['dob'];
    $mail=$_POST['email'];
    $gender=$_POST['gender'];
    $phone=$_POST['phone'];
    $address=$_POST['address'];
    $password=$_POST['psw'];
  //$pass = password_hash($password,PASSWORD_DEFAULT);
    // $con_password=$_POST['con_password'];
    $sql_u = "SELECT * FROM teacher WHERE name='$name'";
    $result = mysqli_query($con, $sql_u);

    if(mysqli_num_rows($result)){
      echo "User already exists";
    }
    else {
      $reg = " insert into teacher (name,branch,subject,co_ordinator,gender,dob,phone,mail,address,password) values
      ( '$name','$branch','$subject','$co_ordinator','$gender','$dob','$phone','$mail','$address','$password')";
      mysqli_query($con, $reg);
       $rslt = mysqli_query($con,"SELECT tid FROM teacher where name='$name'");
       while($row = mysqli_fetch_array($rslt))
          $usn = $row['tid'];
      echo "<center><table>
      <tr><td>Id</td><td>$usn</td></tr>
      <tr><td>Name</td><td>$name</td></tr>
      <tr><td>Branch</td><td>$branch</td></tr>
      <tr><td>Subject</td><td>$subject</td></tr>
      <tr><td>co_ordinator of</td><td>$co_ordinator</td></tr>
      <tr><td>Gender</td><td>$gender</td></tr>
      <tr><td>DOB</td><td>$dob</td></tr>
      <tr><td>Phone</td><td>$phone</td></tr>
      <tr><td>MAIL</td><td>$mail</td></tr>
      <tr><td>Email Id</td><td>$address</td></tr>



      </table></center>";
    }

     ?>
     <center><a href="../HOD/action.php"><button class="btn" type="button" ><b>Go Back</b></button></a></center>
  </body>

</html>
