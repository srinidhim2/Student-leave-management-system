<style media="screen">
#myInput {
  background-image: url('/css/searchicon.png'); /* Add a search icon to input */
  background-position: 10px 12px; /* Position the search icon */
  background-repeat: no-repeat; /* Do not repeat the icon image */
  width: 100%; /* Full-width */
  font-size: 16px; /* Increase font-size */
  padding: 12px 20px 12px 40px; /* Add some padding */
  border: 1px solid #ddd; /* Add a grey border */
  margin-bottom: 12px; /* Add some space below the input */
}

#myTable {
  border-collapse: collapse; /* Collapse borders */
  width: 100%; /* Full-width */
  border: 1px solid #ddd; /* Add a grey border */
  font-size: 18px; /* Increase font-size */
}

#myTable th, #myTable td {
  text-align: left; /* Left-align text */
  padding: 12px; /* Add padding */
}

#myTable tr {
  /* Add a bottom border to all table rows */
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  /* Add a grey background color to the table header and on hover */
  background-color: #f1f1f1;
}

</style>

<?php
  session_start();
  include '../assets/HODheader.html';
  echo "<input type='text' id='myInput' onkeyup='myFunction()' placeholder='Search for names..'>";
   $con=mysqli_connect("localhost","root","","attendence");
   // Check connection
   if(mysqli_connect_errno()) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
   }

   $result = mysqli_query($con,"select * from teacher;");

   echo "<table border='1' id='myTable'>
      <tr class='header'>
         <th>Id</th>
         <th>Name</th>
         <th>Subject</th>
         <th>Branch</th>
         <th>Co_ordinator</th>
         <th>gender</th>
         <th>DOB</th>
         <th>phone</th>
         <th>mail</th>
         <th>Address</th>
         <th>Delete</th>
      </tr>";

   while($row = mysqli_fetch_array($result)) {
      echo "<tr>";
      echo "<td>" . $row['tid'] . "</td>";
      echo "<td>" . $row['name'] . "</td>";
      echo "<td>" . $row['branch'] . "</td>";
      echo "<td>" . $row['subject'] . "</td>";
      echo "<td>" . $row['co_ordinator'] . "</td>";
      echo "<td>" . $row['gender'] . "</td>";
      echo "<td>" . $row['dob'] . "</td>";
      echo "<td>" . $row['phone'] . "</td>";
      echo "<td>" . $row['mail'] . "</td>";
      echo "<td>" . $row['address'] . "</td>";
      echo "
          <td width='140px'>
          <form action='delete.php' method='get'>
            <a href='delete.php'><button class='button1' name='status' value=".$row['tid'].">Delete</button></a>
          </form></td>";
      echo "</tr>";
   }
   echo "</table>";

   mysqli_close($con);
?>
<script>
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
<!-- <br><center><a href="../HOD/teachers.php"  ><button  class="btn" ><b>GO BACK</b></button></a> -->
</center>
