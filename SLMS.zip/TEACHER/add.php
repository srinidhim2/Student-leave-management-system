<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
  font-family: Calibri, Helvetica, sans-serif;
  background-color: pink;
}
.container {
    /* padding: 50px; */
  background-color: lightblue;
}

input[type=text], input[type=password], textarea {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
input[type=text]:focus, input[type=password]:focus {
  background-color: orange;
  outline: none;
}
 div {
            padding: 10px 0;
         }
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}
.registerbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}
.registerbtn:hover {
  opacity: 1;
}
</style>
</head>
<body>
  <!-- <?php
  session_start();
  include '../assets/HODheader.html';
    ?> -->
<form action="register.php" method="post">
  <div class="container">
  <center>  <h1> Teacher Registeration Form</h1> </center>
  <hr>
  <!-- <label> USN </label>
<input type="text" name="usn" placeholder= "usn" size="15" required /> -->
<label> Name: </label>
<input type="text" name="name" placeholder="Name"  required />

<div>
<label>
Branch :
</label>

<select name="branch">
<option value="">Branch</option>
<option value="CSE">CSE</option>
<option value="ISE">ISE</option>
<option value="EC">EC</option>
<option value="ME">ME</option>
<option value="CV">CV</option>
</select>
</div>
<div>
<label>
SUBJECT :
</label>

<select name="subject">
<option value="">subject</option>
<option value="ME">ME</option>
<option value="ATC">ATC</option>
<option value="CNS">CNS</option>
<option value="DBMS">DBMS</option>
<option value="ADP">ADP</option>
<option value="UP">UP</option>
</select>
</div>
<div>
<label>
Co Ordinator of :
</label>

<select name="classid">
<option value="">--None--</option>
<option value="1">1</option>
<option value="2">2</option>
</select>
</div>
<div>
<label>
Gender :
</label><br>
<input type="radio" value="Male" name="gender" checked > Male
<input type="radio" value="Female" name="gender"> Female
<input type="radio" value="Other" name="gender"> Other

</div>
<div >
  <label>DOB</label>
  <input type="date" name="dob">
</div>


<label>
Phone :
</label>
<!-- <input type="text" name="country code" placeholder="Country Code"  value="+91" size="2"/> -->
<input type="text" name="phone" placeholder="phone no." size="10"/ required>
<label for="email"><b>Email</b></label>
<input type="text" placeholder="Enter Email" name="email" required>

Current Address :
<textarea name="address" cols="80" rows="5" placeholder="Current Address" value="address" required>
</textarea>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>

    <label for="psw-repeat"><b>Re-type Password</b></label>
    <input type="password" placeholder="Retype Password" name="psw-repeat" required>
    <button type="submit" class="registerbtn">Register</button>
</form>
</body>
</html>
