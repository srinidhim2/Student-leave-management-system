

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Update Details</title>
    <!-- <link rel="stylesheet" href="style.css"> -->
<style>
        body{
    background-image: url(../mountains2.jpg);
    background-repeat: no-repeat;
    background-size: cover;

    }
    .internal
    {
    background-color: beige;
    color:black;
    border: 4px solid black;
    width:500px;
    transform :translate(2000px,-600px);
    height: 700px;
    padding: 20px;
  }
  .button1 {
    background-color: rgb(142, 133, 143);
    color: #e7e7e7; color: black;
    border: 2px solid #000000;
    border-radius: 12px;
  }

  .button1:hover {
    background-color: #0f130f;
    color: white;
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
  }
</style>
<script type="text/javascript">
function onChange() {
  const password = document.querySelector('input[name=password]');
  const confirm = document.querySelector('input[name=confirm]');
  if (confirm.value === password.value) {
    confirm.setCustomValidity('');
  } else {
    confirm.setCustomValidity('Passwords do not match');
  }
}

</script>
</head>
<body>
  <?php
  session_start();
  include '../assets/theader.html';
  $con = mysqli_connect('localhost','root',"");
  mysqli_select_db($con, 'attendence');
  $tid=$_SESSION['tid'];
  $rslt = mysqli_query($con,"SELECT * FROM teacher where tid='$tid'");
  while($row = mysqli_fetch_array($rslt))
  {
     $tid = $row['tid'];
     $name=$row['name'];
     $branch=$row['branch'];
     $subject=$row['subject'];
     $co_ordinator=$row['co_ordinator'];
     $gender=$row['gender'];
     $dob=$row['dob'];
     $phone=$row['phone'];
     $mail=$row['mail'];
     $address=$row['address'];
     // $password=$row['password'];
   }
   ?>
    <h1 style="text-align: center;background-color: black;color: white;padding: 30px;transform: translate(-35px,-23px);width: 98%;font-size: 40px;">Update Your Details</h1>
    <div class="main">
        <center>
        <div class="internal" style="text-align: left;border: 4px solid black;transform: translateY(-40px);">
            <form action="updation.php" method="post">
                <!-- ID: <input type="text" name="tid" value="<?=$tid?>"><br><br><br> -->
                Name : <input type="text" name="name" value="<?=$name?>"><br><br><br>
                Branch : <input type="text" name="branch" value="<?=$branch?>"><br><br><br>
                subject: <input type="text" name="subject" value="<?=$subject?>"><br><br><br>
                co_ordinator: <input type="text" name="co_ordinator" value="<?=$co_ordinator?>"><br><br><br>
                gender: <input type="text" name="gender" value="<?=$gender?>"><br><br><br>
                dob: <input type="text" name="dob" value="<?=$dob?>"><br><br><br>
                Phone: <input type="text" name="phone" value="<?=$phone?>"><br><br><br>
                Mail: <input type="text" name="mail" value="<?=$mail?>"><br><br><br>
                address: <input type="text" name="address" value="<?=$address?>"><br><br><br>
                Password : <input name="password" type="password" onChange="onChange()" value="" /><br><br><br>
                Conform Password:<input name="confirm"  type="password" onChange="onChange()" /><br><br><br>
               <center><input class="button1" style="height: 40px;width: 110px;font-size: 20px;" type="submit" name="submit" value="SUBMIT"></center> <BR>
            </form>
        </div>
    </center>
    </div>
</body>
</html>
