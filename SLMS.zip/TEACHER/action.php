<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->

    <title>Action</title>
    <style media="screen">

      body{
        background: url(../mountains2.jpg);
        background-repeat: no-repeat;
        background-size: cover;
      }
      /* .a{
        margin-left: 10%;
        margin-top: 10%;
      }
      .b{
        margin-right: 90%;
        margin-top: 10%;
      } */
      th, td {
        text-align: left;
        padding: 8px;
      }

      tr{background-color: #f2f2f2}

      th {
        background-color: #04AA6D;
        color: white;
      }
      .ali{

        margin-left: 0%;
        margin-top: 0%;
      }

    </style>
  </head>
  <body>
    <?php
    session_start();
    $tid=$_SESSION['tid'];
    $con=mysqli_connect("localhost","root","","attendence");
    $res = mysqli_query($con,"select * from event where co_ordinator='$tid' and approveT='0' and approveH='0'");
    $num = mysqli_num_rows($res);
    $res1 = mysqli_query($con,"select * from event where approveH='1'");
    $num1 = mysqli_num_rows($res1);
    // $res2 = mysqli_query($con,"select * from teacher where tid='$tid'");required!!!!!!!!!!!!!
    $_SESSION['num']=$num;
    $_SESSION['num1']=$num1;
    // $row=mysqli_fetch_array($res2);
    // echo $_SESSION['num1'];
    include '../assets/theader.html';
    if(!isset($_SESSION['tid']))
    {
      header('location:user.php');
    }
    else {
      header('locaion:#');
    }
    //dont delete!!!!!!!//
   //  while($row = mysqli_fetch_array($res2))
   //  {
   // echo "<div class='ali'><table border='1' class='a' style='float:left;'>
   // <tr><td colspan=2>Your Details</td></tr>
   // <tr><th>Id</th><td>$row[0]</td></tr>
   // <tr><th>Name</th><td>$row[1]</td></tr>
   // <tr><th>Branch</th><td>$row[2]</td></tr>
   // <tr><th>Subject</th><td>$row[3]</td></tr>
   // <tr><th>co_ordinator of</th><td>$row[4]</td></tr>
   // <tr><th>Gender</th><td>$row[5]</td></tr>
   // <tr><th>DOB</th><td>$row[6]</td></tr>
   // <tr><th>Phone</th><td>$row[7]</td></tr>
   // <tr><th>MAIL</th><td>$row[8]</td></tr>
   // <tr><th>Email Id</th><td>$row[9]</td></tr>
   //
   //
   //
   // </table>";
    // echo "
    // <table border='1' class='b' style='float:left;'>
    // <tr>
    // <th>Leaves requests</th>
    // </tr>
    // <tr>
    // <td>".$num."</td>
    // </tr>
    // </table><br><br><br><br><br>";
    // echo "<table border='1' class='b' style='float:left;'>
    // <tr>
    // <th>Approved requests</th>
    // </tr>
    // <tr>
    // <td>".$num1."</td>
    // </tr>
    // </table></div>";
 //    "</div>";
 // }
     ?>

    </div>
  </body>
</html>
