<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Admin Login</title>
    <style media="screen">
      .container{
        margin-top:10%;
        margin-left:40%;
      }
      body {
        background: url(../mountains2.jpg);
        background-repeat: no-repeat;
        background-size: cover;

}
.btn:hover{
  background: rgb(2,0,36);
  background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(158,176,27,1) 35%, rgba(0,212,255,1) 100%);
border: none;
color: Black;
padding: 18px 36px;
text-align: center;
font-size: 16px;
margin: 4px 2px;
opacity: 0.6;
transition: 0.3s;
display: inline-block;
text-decoration: none;
cursor: pointer;
}

.container {
  color: black;
  width: 400px;
  height: 260px;
  /* display: flex; */
  /* justify-content: center;
  align-items: center; */
  margin-left: 10%;
  margin-top: 10%;
}
input[type="text"] {
border: 2px solid red;
border-radius: 4px;
background-color: #2471A3;
 color: white
}
input[type="password"] {
border: 2px solid red;
border-radius: 4px;
background-color: #2471A3;
 color: white;
}

.button {
  background-color: #2471A3; /* Green */
  border: none;
  color: white;
  padding: 16px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white;
  color: black;
  border: 2px solid #4CAF50;
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
.ali{
  margin-left: 18%;

}

.login{
        width: 382px;
        overflow: hidden;
        margin: auto;
        margin: 20 0 0 450px;
        margin-top: 5%;
        margin-left: 33%;
        padding: 80px;
        background: #23463f;
        border-radius: 15px ;

}
    </style>

  </head>
  <body bgcolor=#76D7C4>
<div class="login">


    <!-- <div class="container"> -->


     <form name="form1" action="login.php" method="post" >
      <center><img src="stud.png" width="200" height="200"></center>
      <div class="ali">


      <label for="Username" style="color:white" >Username:</label><input align="middle" type="text" name="mail" placeholder="EMail"  required><br>
      <label for="password" style="color:white">Password :</label><input align="middle" type="password" name="password" minlength="4"  required><br>
      </div>
        <center><button class="button button1" >LOGIN</button></center>
          <center><a href="../index.php"><button class="button button1" type="button" ><b>Go Back</b></button></a></center>

    </form>

    <!-- </div> -->
</div>
  </body>
</html>
