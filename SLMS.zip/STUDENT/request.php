<!DOCTYPE html>
<html>
<head>
<style>
* {
  box-sizing: border-box;
}

input[type=text],[type=date],[type=file], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}

</style>
</head>
<body>
  <?php
  session_start();
  include '../assets/sheader.html';
 ?>

<h2><center>Apply for Leave</center></h2>

<div class="container">
  <form action="eventcon.php" method="post"  enctype="multipart/form-data">

  </div>
  <div class="row">
    <div class="col-25">
      <label for="lname">Event Name</label>
    </div>
    <div class="col-75">
      <input type="text" id="lname" name="eventname" placeholder="Event name..">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="lname">Co-Ordinator</label>
    </div>
    <div class="col-75">
      <input type="text" id="lname" name="co_ordinator" placeholder="co_ordinator id">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="country">Date</label>
    </div>
    <div class="col-75">
      <input type="date" name="date" value="">
      </select>
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="country">No of days:</label>
    </div>
    <div class="col-75">
      <input type="text" name="days" value="">
      </select>
    </div>
  </div>

  <div class="row">
    <div class="col-25">
      <label for="subject">Description</label>
    </div>
    <div class="col-75">
      <textarea id="subject" name="description" placeholder="Write something.." style="height:200px"></textarea>
    </div>
  </div>
  <br>
  <!-- <div class="row">
    <div class="col-25">
  <label for="document">Upload file:</label>
<input class="container" type="file" name="document" value="">
</div>
</div> -->
  <input type="file" name="file">
    <br>
  <div class="row">
    <input type="submit" value="Submit">
  </div>
  </form>
</div>

</body>
</html>
