<style media="screen">
table {
  border-collapse: collapse;
  width: 50%;
  margin-left: 25%;
  /* margin-top: 10%; */
}
/* .btn:hover{
  background: rgb(2,0,36);
background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(158,176,27,1) 35%, rgba(0,212,255,1) 100%);
  /* background-color: white; */
border: none;
color: brown;
padding: 18px 36px;
text-align: center;
font-size: 16px;
margin: 4px 2px;
opacity: 0.6;
transition: 0.3s;
display: inline-block;
text-decoration: none;
cursor: pointer;
} */
.button1 {background-color: #4CAF50;}
.button2 {background-color: #f44336;}
th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #04AA6D;
  color: white;
}
</style>
<?php
session_start();
include '../assets/sheader.html';
   $con=mysqli_connect("localhost","root","","attendence");
   // Check connection
   if(mysqli_connect_errno()) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
   }
   $usn=$_SESSION['usn'];
   $result = mysqli_query($con,"SELECT * FROM event WHERE usn=$usn");

   echo "<br><br><table border='1'>
      <tr>
         <th>Request Id</th>
         <th>Event Name</th>

         <th>Co_ordinator</th>
         <th>Date</th>
         <th>No of Days</th>
         <th>Description</th>
         <th>Approved by co-ordinator</th>
         <th>Approved by HOD</th>
      </tr>";

   while($row = mysqli_fetch_array($result)) {
     if($row['approveH']==1){
                $statusH="Approved";
              }
              if($row['approveH']==0){
                $statusH="Pending";
              }
              if($row['approveH']==2){
                $statusH="Rejected";
              }
        if($row['approveT']==1){
                   $statusT="Approved";
                 }
                 if($row['approveT']==0){
                   $statusT="Pending";
                 }
                 if($row['approveT']==2){
                   $statusT="Rejected";
                 }

      echo "<tr>";
      echo "<td>" . $row['requestid'] . "</td>";
      echo "<td>" . $row['eventname'] . "</td>";

      echo "<td>" . $row['co_ordinator'] . "</td>";
      echo "<td>" . $row['date'] . "</td>";
      echo "<td>" . $row['days'] . "</td>";
      echo "<td>" . $row['description'] . "</td>";
      echo "<td>".$statusT."</td>";
      echo "<td>".$statusH."</td>";        ;
      // echo "<td><input name='checkH' type='button' value='Approve'></td>";
      echo "</tr>";

 }
   echo "</table>";


   mysqli_close($con);

?>
<br><center><a href="action.php"  ><button  class="btn" ><b>GO BACK</b></button></a><br>

</center>
