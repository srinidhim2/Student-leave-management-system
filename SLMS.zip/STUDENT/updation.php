<?php
session_start();
$con = mysqli_connect('localhost','root',"");
mysqli_select_db($con, 'attendence');
if(isset($_SESSION['usn']))
       {

           $usn=$_SESSION['usn'];
               if(isset($_POST['submit']))
               {
                 // $id = $row['tid'];
                 $name=$_POST['name'];
                 $branch=$_POST['branch'];
                 $classid=$_POST['classid'];
                 $mail=$_POST['mail'];
                 $phone=$_POST['phone'];
                 $dob=$_POST['dob'];
                 $gender=$_POST['gender'];
                 $address=$_POST['address'];
                 $password=$_POST['password'];
                 $query3 = mysqli_query($con,"UPDATE student SET
                   name='$name',branch='$branch',classid='$classid',mail='$mail',phone='$phone',dob='$dob',gender='$gender', address='$address', password='$password' WHERE usn='$usn'");

                   if ($query3){

                        echo "<script type='text/javascript'>alert('Successful - Record Updated!'); window.location.href = 'action.php';</script>";
                     }
                   else
                       { echo "<script type='text/javascript'>alert('Unsuccessful - ERROR!'); window.location.href = 'user_list.php';</script>"; }
               }

   // $query1=mysql_query("SELECT * FROM student WHERE usn='$usn'");
   // $query2=mysql_fetch_array($query1);



   }
 ?>
