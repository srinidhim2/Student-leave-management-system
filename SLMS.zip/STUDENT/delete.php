<?php
session_start();
$con = mysqli_connect('localhost','root',"");
mysqli_select_db($con, 'attendence');
// Check connection
$usn=$_GET['status'];
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}

// sql to delete a record
$sql_v= "SELECT * FROM student WHERE usn=$usn";
$query=mysqli_query($con,$sql_v);
if(mysqli_num_rows($query))
{


  $sql = "DELETE FROM student WHERE usn=$usn";
  mysqli_query($con, $sql);
  header('location:record.php');
  // echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . mysqli_error($con);
}
mysqli_close($con);
?>
<center><a href="../HOD/students.php"><button class="btn" type="button" ><b>Go Back</b></button></a></center>
