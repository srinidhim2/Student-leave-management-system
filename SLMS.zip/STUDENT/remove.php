
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="delete.php" method="post">
        <input type="text" name="usn" value="">
        <input type="submit" name="submit" value="remove">
    </form>
  </body>
</html>
