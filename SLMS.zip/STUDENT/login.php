<?php
session_start();
$con = mysqli_connect('localhost','root',"",'attendence');

$mail=strval($_POST['mail']);
$password=strval($_POST['password']);

$sql_u = "SELECT * FROM student WHERE mail='$mail' && password='$password'";
$result = mysqli_query($con, $sql_u);

if(mysqli_num_rows($result)){
  while($row = mysqli_fetch_array($result))
  {
    $_SESSION['usn'] = $row['usn'];
    $_SESSION['name'] = $row['name'];
  }
// echo $_SESSION['name'];
  echo "<script type='text/javascript'>alert('LOGIN Successful'); window.location.href = 'action.php';</script>";
}
else
{

echo "<script type='text/javascript'>alert('Incorrect Details!'); window.location.href = 'slogin.php';</script>";
}

?>
