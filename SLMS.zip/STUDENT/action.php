<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Student DASHBOARD</title>
    <style media="screen">

      body{
        background: url(../mountains2.jpg);
        background-repeat: no-repeat;
        background-size: cover;
      }

    </style>
  </head>
  <body>
    <?php
    session_start();
    include '../assets/sheader.html';


    if(!isset($_SESSION['usn']))
    {
      header('location:user.php');
    }

     ?>
  
    </div>
  </body>
</html>
