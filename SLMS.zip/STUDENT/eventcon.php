
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">

    .btn:hover{
      background: rgb(2,0,36);
    background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(158,176,27,1) 35%, rgba(0,212,255,1) 100%);
    border: none;
    color: Black;
    padding: 18px 36px;
    text-align: center;
    font-size: 16px;
    margin: 4px 2px;
    opacity: 0.6;
    transition: 0.3s;
    display: inline-block;
    text-decoration: none;
    cursor: pointer;
    }
    </style>
  </head>
  <body>
    <?php
     session_start();
    $con = mysqli_connect('localhost','root',"");
    mysqli_select_db($con, 'attendence');
    // $usn=$_POST['usn'];
    $usn=$_SESSION['usn'];
    $eventname=$_POST['eventname'];
    $co_ordinator=$_POST['co_ordinator'];
    $date=$_POST['date'];
    $days=$_POST['days'];
    $description=$_POST['description'];
    $statusMsg = '';

// File upload path
$targetDir = "uploads/";
$fileName = basename($_FILES["file"]["name"]);
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

// if(isset($_POST["submit"]) && !empty($_FILES["file"]["name"])){
//     // Allow certain file formats
//     $allowTypes = array('jpg','png','jpeg','gif','pdf');
//     if(in_array($fileType, $allowTypes)){
//         // Upload file to server
//         if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
//             // Insert image file name into database
//             // $insert = $db->query("INSERT into images (file_name, uploaded_on) VALUES ('".$fileName."', NOW())");
//
//
//     }
//     }
// }
move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath);
$reg = " insert into event(eventname,usn,co_ordinator,date,days,description,file_name) values
( '$eventname','$usn','$co_ordinator','$date','$days','$description','$fileName')";
mysqli_query($con, $reg);
$sql_u = "SELECT * FROM event WHERE eventname='$eventname'";
$result = mysqli_query($con, $sql_u);
       while($row = mysqli_fetch_array($result))
          $eventid = $row['requestid'];
      echo "<center><table border='1'>
      <tr><td>Request Id</td><td>$eventid</td></tr>
      <tr><td>Event Name</td><td>$eventname</td></tr>
      <tr><td>usn</td><td>$usn</td></tr>
      <tr><td>CO-Co_ordinator</td><td>$co_ordinator</td></tr>
      <tr><td>Date</td><td>$date</td></tr>
      <tr><td>Days</td><td>$days</td></tr>
      <tr><td>Description</td><td>$description</td></tr>

      </table></center>";


     ?>
     <center><a href="action.php"><button  type="button" ><b>Go Back</b></button></a></center>
  </body>

</html>
