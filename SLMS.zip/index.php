<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Event Management System</title>
    <style>
    body{
   background: url(mountains2.jpg);
   background-repeat: no-repeat;
   background-size: cover;

    }
    .containar{
          width: 90%;
          margin: 0 auto; /* Center the DIV horizontally */
      }
      .fixed-header, .fixed-footer{
          width: 100%;
          height: 10%;
          position: fixed;
          background: #444;
          padding: 0px 0;
          padding-left: 0px 0;
          color: #fff;
      }
      .fixed-header{
          top: 0;
      }
      .fixed-footer{
          bottom: 0;
      }
      /* Some more styles to beutify this example */
      nav a{
          color: #fff;
          text-decoration: none;
          padding: 7px 25px;
          display: inline-block;
      }
      .container p{
          line-height: 200px; /* Create scrollbar to test positioning */
      }

</style>
  </head>
  <body >

     <?php include 'assets/header.html' ?>
     <center><h1 style="color:White;">Event Management System</h1></center>

  </body>
</html>
