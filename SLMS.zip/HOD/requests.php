<style media="screen">
#myInput {
  /* background-image: url('../search.png'); /* Add a search icon to input */ */
  background-position: 10px 12px; /* Position the search icon */
  background-repeat: no-repeat; /* Do not repeat the icon image */
  width: 100%; /* Full-width */
  font-size: 16px; /* Increase font-size */
  padding: 12px 20px 12px 40px; /* Add some padding */
  border: 1px solid #ddd; /* Add a grey border */
  margin-bottom: 12px; /* Add some space below the input */
}

table {
  border-collapse: collapse;
  width: 50%;
  margin-left: 25%;
  margin-top: 1%;
  /* margin-top: 10%; */
}
/* .btn:hover{
  background: rgb(2,0,36);
background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(158,176,27,1) 35%, rgba(0,212,255,1) 100%);
  /* background-color: white; */
border: none;
color: brown;
padding: 18px 36px;
text-align: center;
font-size: 16px;
margin: 4px 2px;
opacity: 0.6;
transition: 0.3s;
display: inline-block;
text-decoration: none;
cursor: pointer;
} */
.button1 {background-color: #4CAF50;}
.button2 {background-color: #f44336;}
.view {background-color: lightblue;}
th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #04AA6D;
  color: white;
}
a{
  text-decoration: none;
}
</style>
<script type="text/javascript">
function myFunction() {
// Declare variables
var input, filter, table, tr, td, i, txtValue;
input = document.getElementById("myInput");
filter = input.value.toUpperCase();
table = document.getElementById("myTable");
tr = table.getElementsByTagName("tr");

// Loop through all table rows, and hide those who don't match the search query
for (i = 0; i < tr.length; i++) {
  td = tr[i].getElementsByTagName("td")[0];
  if (td) {
    txtValue = td.textContent || td.innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      tr[i].style.display = "";
    } else {
      tr[i].style.display = "none";
    }
  }
}
}
</script>
<?php
  session_start();
  include '../assets/HODheader.html';
  // echo "<input type='text' id='myInput' onkeyup='myFunction()' placeholder='Search for names..'>";

   $con=mysqli_connect("localhost","root","","attendence");
   // Check connection
   if(mysqli_connect_errno()) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
   }

   $result = mysqli_query($con,"SELECT * FROM event");

   echo "<table id='myTable' border='1'>
      <tr>
         <th>Request Id</th>
         <th>Event Name</th>
         <th>USN</th>
         <th>Co_ordinator</th>
         <th>Date</th>
         <th>No of Days</th>
         <th>Description</th>
         <th>Approved by co-ordinator</th>
         <th>Approved by HOD</th>
         <th>Permission letter</th>
      </tr>";

   while($row = mysqli_fetch_array($result)) {
       if($row['approveH']==0 ){

        if($row['approveT']==1){
                   $status="Approved";
                 }
                 if($row['approveT']==0){
                   $status="Pending";
                 }
                 if($row['approveT']==2){
                   $status="Rejected";
                 }
      echo "<tr>";
      echo "<td>" . $row['requestid'] . "</td>";
      echo "<td>" . $row['eventname'] . "</td>";
      echo "<td>" . $row['usn'] . "</td>";
      echo "<td>" . $row['co_ordinator'] . "</td>";
      echo "<td>" . $row['date'] . "</td>";
      echo "<td>" . $row['days'] . "</td>";
      echo "<td>" . $row['description'] . "</td>";
      echo "<td>".$status."</td>";
      echo "
          <td width='140px'>
          <form action='accept.php' method='get'>
            <a href='accept.php'><button class='button1' name='status' value=".$row['requestid'].">Approve</button></a>
          </form>
          <form action='reject.php' method='get'>
              <a href='reject.php'><button class='button2' name='status' value=".$row['requestid'].">Reject</button></a>
          </form></td>
          "
        ;
      // echo "<td><input name='checkH' type='button' value='Approve'></td>";
 //      echo "</tr>";
 //   }
 // }
 //   echo "</table>";
 //
 //
 //   mysqli_close($con);

?>
<!-- <br><center><a href="HOD/action.php"  ><button  class="btn" ><b>GO BACK</b></button></a><br> -->
<td><button class="view"><a href="../STUDENT/uploads/<?php echo $row['file_name'];?>">View</a><button></td></tr>
<?php
    }
  }
 ?>
</table>

</center>
