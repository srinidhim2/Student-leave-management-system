<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <script>
    function myFunction() {
      var x;
      var r = confirm("Confirm to Delete");
      if (r == true) {
        location.href="delete.php";
      }
  else {
          x = "You pressed Cancel!";
          location.href="del.php";

        }

        //document.getElementById("demo").innerHTML = x;

    }

</script>
  </head>
  <body>
    <form class="" action="delete.php" method="post">
      <input type="text" name="u_id">
      <input type="submit" name="submit" onclick="">

    </form>

  </body>
</html>
