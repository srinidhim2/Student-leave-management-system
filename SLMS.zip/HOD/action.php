<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>DASHBOARD</title>
    <style media="screen">


      body{
      background: url(../mountains2.jpg);
      background-repeat: no-repeat;
      background-size: cover;

      }

    </style>
  </head>
  <body>
    <?php
    session_start();
    $name=$_SESSION['username'];
    $con=mysqli_connect("localhost","root","","attendence");

    $res1 = mysqli_query($con,"select * from event where approveH='0'");
    $num1 = mysqli_num_rows($res1);
    $_SESSION['num1']=$num1;
    include '../assets/HODheader.html';
    // $res2 = mysqli_query($con,"select * from teacher where tid='$tid'");

    // echo $_SESSION['num1'];
    if(!isset($_SESSION['username']))
    {
      header('location:admin.php');
    }

     ?>

    </div>
  </body>
</html>
