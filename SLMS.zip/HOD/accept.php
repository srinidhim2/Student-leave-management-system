<?php
session_start();
$con = mysqli_connect('localhost','root',"");
mysqli_select_db($con, 'attendence');
// Check connection
$id=$_GET['status'];
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
echo $id;
$query=(" update  event SET approveH=1 where requestid=$id");
mysqli_query($con,$query);
header('location:requests.php');
// // sql to delete a record
// $sql_v= "SELECT * FROM u_login WHERE u_id=$id";
// $query=mysqli_query($con,$sql_v);
// if(mysqli_num_rows($query))
// {
//   $sql = "DELETE FROM u_login WHERE u_id=$id";
//   mysqli_query($con, $sql);
//   echo "Record deleted successfully";
// } else {
//   echo "Error deleting record: " . mysqli_error($con);
// }

mysqli_close($con);
?>
