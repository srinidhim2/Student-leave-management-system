<?php
session_start();
$con = mysqli_connect('localhost','root',"");
mysqli_select_db($con, 'attendence');
$name=$_POST['username'];
$password=$_POST['password'];
$sql_u = "SELECT * FROM login WHERE user='$name' && password = '$password'";
$result = mysqli_query($con, $sql_u);

if(mysqli_num_rows($result)){
  $_SESSION['username'] = $name;

  echo "<script type='text/javascript'>alert('LOGIN Successful'); window.location.href = 'action.php';</script>";

}
else
{

  echo "<script type='text/javascript'>alert('Incorrect Details!'); window.location.href = 'admin.php';</script>";

}

?>
